"""
Wraps CybORG CAGE-4 to record stage reach metrics:
P(Compromise | Discover), P(Root | Compromise), and P(Impact | Root) on every step().
Tracks host-level operational disruptions (DegradeServices and Impact).
"""

from typing import Dict, Any, Tuple
from CybORG import CybORG as cb
from CybORG.Simulator.Scenarios.EnterpriseScenarioGenerator import EnterpriseScenarioGenerator
from CybORG.Agents.SimpleAgents.EnterpriseGreenAgent import EnterpriseGreenAgent
from src.env.state_parser import CyBORGStateParser as cbParser


class StageGatedCyBORGEnv:
    def __init__(self, scenario_config: str = None, seed: int = 123, steps: int = 80):
        sg = EnterpriseScenarioGenerator(green_agent_class=EnterpriseGreenAgent, steps=steps)
        self.cyborg = cb(scenario_generator=sg, seed=seed)
        self.agent_name = "red_agent_0"
        self.max_steps = steps
        self.parser = cbParser()
        self.reset_telemetry()

    def reset_telemetry(self):
        self.discovered_hosts: set = set()
        self.compromised_hosts: set = set()
        self.rooted_hosts: set = set()
        self.impacted_hosts: set = set()
        self.impact_achieved: bool = False
        self.current_step: int = 0
        self._action_in_flight: Any = None

    def reset(self) -> Tuple[Dict[str, Any], Any]:
        results = self.cyborg.reset(agent=self.agent_name)
        self.reset_telemetry()
        self._update_telemetry(results.observation)
        return results.observation, results.action_space

    def step(self, action: Any) -> Tuple[Dict[str, Any], float, bool, Dict[str, Any]]:
        self.current_step += 1
        results = self.cyborg.step(action=action, agent=self.agent_name)
        self._update_telemetry(results.observation)

        status_str = str(results.observation.get("success", "")).upper()

        # Multi-tick action tracking (DegradeServices, Impact, PrivilegeEscalate have duration=2)
        if "IN_PROGRESS" in status_str:
            if self._action_in_flight is None:
                self._action_in_flight = action
        else:
            completed_action = self._action_in_flight if self._action_in_flight is not None else action
            self._action_in_flight = None
            action_name = getattr(completed_action, "name", str(completed_action))
            action_success = "TRUE" in status_str

            # CybORG CAGE-4 uses DegradeServices for service disruption (and Impact on specialized targets)
            if any(k in action_name for k in ("Impact", "DegradeServices")) and action_success:
                self.impact_achieved = True
                target_host = getattr(completed_action, "hostname", str(completed_action).split()[-1])
                self.impacted_hosts.add(target_host)

        # Allow the episode to run across the full horizon so agents can discover and disrupt multiple enterprise servers
        done = self.current_step >= self.max_steps
        info = self.get_stage_metrics()
        info["raw_results"] = results
        return results.observation, results.reward, done, info

    def _update_telemetry(self, obs: Dict[str, Any]):
        discov, compro, root = self.parser.parse_host_sessions(obs)
        self.discovered_hosts.update(discov)
        self.compromised_hosts.update(compro)
        self.rooted_hosts.update(root)

    def get_stage_metrics(self) -> Dict[str, Any]:
        discov_count = len(self.discovered_hosts)
        compro_count = len(self.compromised_hosts)
        root_count = len(self.rooted_hosts)
        impact_count = len(self.impacted_hosts)

        return {
            "step": self.current_step,
            "discovered": discov_count,
            "compromised": compro_count,
            "rooted": root_count,
            "impacted_hosts": impact_count,
            "impact": self.impact_achieved,
            "p_compromise_given_disc": (compro_count / discov_count) if discov_count > 0 else 0.0,
            "p_root_given_comp": (root_count / compro_count) if compro_count > 0 else 0.0,
            "p_impact_given_root": (impact_count / root_count) if root_count > 0 else 0.0,
            "escalation_needed": self.parser.get_escalation_candidates(
                self.compromised_hosts, self.rooted_hosts
            ),
        }


StageGatedCybORGEnv = StageGatedCyBORGEnv
