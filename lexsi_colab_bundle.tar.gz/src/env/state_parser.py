"""
Converts CybORG's nested observation dictionaries into:
1. Kill-chain state: discovered, compromised (user shell), or rooted hosts.
2. Natural LLM Prompts: open operational queries without artificial formatting crutches.
3. Bidirectional IP <-> Hostname mapping and robust observation lookup.
"""

import textwrap
from typing import List, Dict, Any, Set, Tuple


def get_host_obs(obs: dict, target: str) -> dict:
    """
    Safely retrieves the host observation dictionary regardless of whether top-level `obs`
    is keyed by resolved hostname or raw IPv4 address.
    """
    if not isinstance(obs, dict) or not target:
        return {}

    # 1. Direct key match (if obs is already keyed by hostname)
    if target in obs and isinstance(obs[target], dict):
        return obs[target]

    target_lower = str(target).strip().lower()

    # 2. Case-insensitive key match or nested System info / Interface IP match
    for key, val in obs.items():
        if key == "success" or not isinstance(val, dict):
            continue
        if str(key).strip().lower() == target_lower:
            return val

        # Check nested System info Hostname
        sys_info = val.get("System info") or val.get("system_info") or {}
        if isinstance(sys_info, dict):
            hostname = str(sys_info.get("Hostname") or sys_info.get("hostname") or "").strip().lower()
            if hostname == target_lower:
                return val

        # Check nested Interface IP addresses
        interfaces = val.get("Interface") or val.get("interfaces") or []
        if isinstance(interfaces, list):
            for iface in interfaces:
                if isinstance(iface, dict):
                    ip = str(iface.get("IP Address") or iface.get("ip_address") or "").strip().lower()
                    if ip == target_lower:
                        return val

    return {}


class CyBORGStateParser:
    def __init__(self):
        self.ip_to_hostname: Dict[str, str] = {}
        self.hostname_to_ip: Dict[str, str] = {}

    def parse_host_sessions(self, obs: Dict[str, Any]) -> Tuple[Set[str], Set[str], Set[str]]:
        discovered: Set[str] = set()
        compromised: Set[str] = set()
        rooted: Set[str] = set()

        if not isinstance(obs, dict):
            return discovered, compromised, rooted

        for host_key, host_info in obs.items():
            if host_key in ["success", "action"] or not isinstance(host_info, dict):
                continue

            # Resolve true hostname if host_key is an IP address
            sys_info = host_info.get("System info", {})
            hostname = host_key
            if isinstance(sys_info, dict) and "Hostname" in sys_info:
                hostname = sys_info["Hostname"]

            # Record IP to hostname associations
            if "." in str(host_key):
                self.ip_to_hostname[str(host_key)] = hostname
                self.hostname_to_ip[hostname] = str(host_key)

            interfaces = host_info.get("Interface", [])
            for iface in interfaces:
                if isinstance(iface, dict):
                    ip = str(iface.get("ip_address", iface.get("IP Address", "")))
                    if ip:
                        self.ip_to_hostname[ip] = hostname
                        self.hostname_to_ip[hostname] = ip

            discovered.add(hostname)
            sessions = host_info.get("Sessions", [])
            for session in sessions:
                if isinstance(session, dict):
                    agent_val = str(session.get("agent", session.get("Agent", "")))
                    if "red" in agent_val.lower():
                        user_name = str(session.get("username", session.get("Username", "")))
                        compromised.add(hostname)
                        if user_name in ["root", "SYSTEM"]:
                            rooted.add(hostname)

        return discovered, compromised, rooted

    def get_host_obs(self, obs: Dict[str, Any], target: str) -> Dict[str, Any]:
        """Accessor for get_host_obs on parser instance."""
        res = get_host_obs(obs, target)
        if res:
            return res
        if target in self.hostname_to_ip:
            return get_host_obs(obs, self.hostname_to_ip[target])
        return {}

    def get_host_info(self, obs: Dict[str, Any], target_host: str) -> Dict[str, Any]:
        """Safely retrieves host dictionary regardless of whether obs is keyed by IP or hostname."""
        return self.get_host_obs(obs, target_host)

    @staticmethod
    def get_escalation_candidates(compromised: Set[str], rooted: Set[str]) -> List[str]:
        """Returns hosts that have unprivileged user shell access but not root."""
        return list(compromised - rooted)

    @staticmethod
    def format_llm_privesc_prompt(
        host_name: str, host_info: Dict[str, Any], available_actions: List[Any]
    ) -> str:
        os_info = host_info.get("System info", {}).get("OSType", "Linux")
        services = host_info.get("Services", [])

        candidate_actions = [str(a) for a in available_actions]
        actions_str = (
            "\n".join(f"- {act}" for act in candidate_actions)
            if candidate_actions
            else "Standard local enumeration and SUID exploitation."
        )

        prompt = f"""[TARGET HOST ENUMERATION]
Host: {host_name}
Operating System: {os_info}
Active Services: {services}

[OBJECTIVE]
Current status: Unprivileged shell access (UID != 0).
Select the optimal next action to escalate privileges on {host_name}.
Respond ONLY with the exact candidate action string from [CANDIDATE ACTIONS]. Do not output preamble or explanation.

[CANDIDATE ACTIONS]
{actions_str}"""
        return textwrap.dedent(prompt).strip()
